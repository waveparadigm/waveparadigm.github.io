/*
    Voice Transcription Node.js

    Listens for a post request containing a wav file, transcribes it using Google Speech API, returns the transcription as json.
*/

//Setup Express
const express = require("express");
const bodyParser = require("body-parser");
var app = express();
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

app.set("port", (process.env.PORT || 5000));
app.use(express.static(__dirname + '/public'));

const busboy = require("connect-busboy");
//const path = require("path");

app.use(busboy());

//Setup google Speech
const Speech = require("@google-cloud/speech");
const fs = require("fs");

const projectId = "voicetranscription-171315";
const speechClient = Speech({
    projectId: projectId
});

//handle posting file
app.route("/").post(function (req, res, next) {
    var fstream;
    console.log("Received post request!");
    filename = "test.wav";
    console.log("Uploading " + filename);

    //path to save file
    var filePath = __dirname + "/audio/" + filename;

    fs.closeSync(fs.openSync(filePath, 'w')); //ensure the file exists

    fstream = fs.createWriteStream(filePath);
    try {
        req.once('data', (chunk) => {
            console.log(chunk.byteLength);
            fstream.write(chunk);
            console.log("wrote chunk to fstream");
        });
        req.once('end', function () {
            fstream.close();
            console.log("Finished uploading " + filename);
            if (fs.existsSync(filePath)) {
                console.log("File found! Transcribing audio...");
                const options =  {
                    encoding: "LINEAR16",
                    languageCode: "en-US"
                };

                speechClient.recognize(filePath, options).then((results) => {
                    //fs.unlinkSync(filePath); //delete file

                    console.log("TRANSCRIPTION: " + results[0]);
                    console.log("Returning string");

                    console.log("\n\n\nListening on port " + app.get("port"));
                    res.json(results[0]);
                }).catch((err) => {
                    //fs.unlinkSync(filePath); //delete file
                    res.json("ERROR: Could not transcribe. " + err);
                    console.log("Error, could not transcribe.");
                });
            }
        });
    } catch (e) {
        res.json(e);
    }
});

var server = app.listen(app.get("port"), function () {
    console.log("Listening on port " + app.get("port"));
});