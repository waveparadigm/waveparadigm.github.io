/*
    Voice Transcription Node.js

    Listens for a post request containing a wav file, transcribes it using Google Speech API, returns the transcription as json.
*/

//Setup Express
const express = require("express");
var app = express();

var bodyParser = require('body-parser');
app.use(bodyParser.json({limit: '5mb'}));
app.use(bodyParser.urlencoded({limit: '5mb'}));

app.set("port", (process.env.PORT || 5000));
app.use(express.static(__dirname + '/public'));

const busboy = require("connect-busboy");
//const path = require("path");
const stream = require("stream");
const Readable = stream.Readable;

app.use(busboy());

//setup nodemailer
const nodemailer = require("nodemailer");

//Setup google Speech
const Speech = require("@google-cloud/speech");
const fs = require("fs");

const projectId = "voicetranscription-171315";
const speechClient = Speech({
    projectId: projectId
});

//audio encoding stuff
const wav = require("node-wav");

//handle posting file
app.route("/").post(function (req, res, next) {
    var fstream;
    req.pipe(req.busboy);
    if (req.busboy) {
        if (req.files == undefined) {
            try {
                req.files = req.body;
            } catch (e) {
                console.log('tried to append body[0] to files, got error ' + e);
            }
        }
        console.log(req.busboy);
        try {
            console.log("Req.busboy exists. Now trying busboy.on(file)");
            req.busboy.on('file', function (fieldname, file, filename) {
                console.log("Uploading " + filename);

                //path to save file
                var filePath = __dirname + "/audio/" + filename;

                fs.closeSync(fs.openSync(filePath, 'w')); //ensure the file exists

                fstream = fs.createWriteStream(filePath);
                console.log("Told fstream to createWriteStream at " + filePath);
                file.pipe(fstream);
                console.log("Piped file to fstream");
                
                //AUDIO STUFF



                //END AUDIO STUFF



                fstream.on('close', function () {
                    console.log("Finished uploading " + filename);
                    if (fs.existsSync(filePath)) {
                        console.log("File found! Transcribing audio...");
                        const options =  {
                            encoding: "LINEAR16",
                            languageCode: "en-US"
                        };

                        speechClient.recognize(filePath, options).then((results) => {
                            fs.unlinkSync(filePath); //delete file

                            console.log("TRANSCRIPTION: " + results[0]);
                            console.log("Returning string");

                            console.log("\n\n\nListening on port " + app.get("port"));
                            res.json(results[0]);
                        }).catch((err) => {
                            fs.unlinkSync(filePath); //delete file
                            res.json("ERROR: Could not transcribe. " + err);
                        });
                    }
                });
            });
            req.busboy.on('finish', function () {
                console.log("got finish");
                
                if (req.body != {} && req.body != undefined && req.body != null && Object.keys(req.body)[0] != undefined) {
                	console.log(Object.keys(req.body)[0].length);
                    console.log("Uploading audio file in 'on finish'");
                    
                    filename = Math.round((new Date()).getTime()).toString() + ".wav"; //unique to the millisecond
                    //path to save file
                    var filePath = __dirname + "/audio/" + filename;

                    fs.closeSync(fs.openSync(filePath, 'w')); //ensure the file exists

                    fstream = fs.createWriteStream(filePath);
                    console.log("Told fstream to createWriteStream at " + filePath);

                    var bufString = Object.keys(req.body)[0];
                    console.log(bufString.length);
                    var buf = Buffer.from(bufString, 'base64');
                    console.log("Filesize: " + buf.byteLength);
                    var decodedString = buf.toString();
                    /*
                    var bufferStream = new stream.PassThrough();
                    bufferStream.end(buf);
                    bufferStream.pipe(fstream)
                    */
                    var readableStr = new Readable();
                    readableStr.push(decodedString);
                    readableStr.push(null);
                    readableStr.pipe(fstream);
                    console.log("Piped file to fstream");

                    fstream.on('close', function () {
                        console.log("Finished uploading " + filename);
                        

                        if (fs.existsSync(filePath)) {
                            console.log("File found! Sending email...");

                            sendMail(filename, buf);

                            console.log("Sent mail. Transcribing audio...");

                            const options =  {
                                encoding: "LINEAR16",
                                languageCode: "en-US",
                                sampleRateHertz: 44100,
                            };

                            speechClient.recognize(filePath, options).then((results) => {
                                fs.unlinkSync(filePath); //delete file

                                console.log(results);

                                console.log("TRANSCRIPTION: " + results[0]);
                                console.log("Returning string");

                                console.log("\n\n\nListening on port " + app.get("port"));
                                res.json("Received body of length " + bufString.length.toString() + ", TRANSCRIPTION: " + results[0]);
                            }).catch((err) => {
                                fs.unlinkSync(filePath); //delete file
                                res.json("ERROR: Could not transcribe. " + err);
                                console.log(err);
                                console.log("\n\n\nListening on port " + app.get("port"));
                            });
                        }
                    });
                }
            });


        } catch (e) {
            res.json("ERROR: " + e);
        }
    } else {
        res.json("Busboy could not be found on req object.");
    }
});

var server = app.listen(app.get("port"), function () {
    console.log("Listening on port " + app.get("port"));
});


/**
 * Sends an email.
 * @function
 */
var sendMail = function (attachmentname, attachmentval) {

  var transporter
    , message;

  transporter = nodemailer.createTransport({
    service: 'Mailgun',
    auth: {
      user: "postmaster@sandboxe01097f1800440bb8e642f7bea44d9f7.mailgun.org", // postmaster@sandbox[base64 string].mailgain.org
      pass: "asdfg" // You set this.
    }
  });
  message = {
    from: 'YourServer ',
    to: 'adam.gincel@prudential.com', // comma separated list
    subject: 'Subject Line',
    text: 'Text contents.',
    html: "<b>Text contents.</b>",
    attachments: [{filename: attachmentname, content: attachmentval}]
  };
  transporter.sendMail(message, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Sent: ' + info.response);
    }
  });
};