const Speech = require("@google-cloud/speech");
const prompt = require("prompt");
const fs = require("fs");
prompt.start();

const express = require("express");
var app = express();

app.set("port", (process.env.PORT || 5000));

app.use(express.static(__dirname + '/public'));


const projectId = "voicetranscription-171315";

const speechClient = Speech({
    projectId: projectId
});

//Prompt the user for the filename
console.log("Enter the name of the wav file in this directory's /resources/ folder: ");
prompt.get(['fileName'], function(err, result) {
    //they've entered a filename
    const fileName = "./resources/" + result.fileName;
    if (fs.existsSync(fileName)) {
        //the file exists
        console.log("File found! Transcribing audio...");
        const options =  {
            encoding: "LINEAR16",
            languageCode: "en-US"
        };

        speechClient.recognize(fileName, options).then((results) => {
            console.log("TRANSCRIPTION: " + results[0]);
        }).catch((err) => {
            console.error("ERROR: ", err);
        });
    } else {
        //file does not exist
        console.log("That file could not be found. Terminating.");
    }
});